# Nifti Tech Invoicing - Android app

1. Install Android Studio (https://developer.android.com/studio).
2. File > Open > select this NiftiInvoicing folder. Let Gradle sync finish.
3. Test: plug in a phone (USB debugging on) or start an emulator, press Run.
4. APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
   Release/Play Store: Build > Generate Signed Bundle / APK.
